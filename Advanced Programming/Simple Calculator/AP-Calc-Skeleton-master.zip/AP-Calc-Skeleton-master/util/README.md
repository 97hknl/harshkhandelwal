Usage `python generate_expressions.py <iterations> <seed>`.
